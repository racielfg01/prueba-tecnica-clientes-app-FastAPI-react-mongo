import axios from 'axios';

const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:8000/api';

const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
  timeout: 30000,
});

api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.clear();
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

export const authService = {
  login: (username, password) => api.post('/auth/login', { username, password }),
  register: (username, email, password) => api.post('/auth/register', { username, email, password }),
  logout: (username) => api.post('/auth/logout', null, { params: { username } }),
};

export const clientesService = {
  listar: (identification, nombre, usuarioId) => api.post('/clientes/listar', null, { 
    params: { identification, nombre, usuarioId } 
  }),
  obtener: (clienteId) => api.get(`/clientes/obtener/${clienteId}`),
  crear: (data) => api.post('/clientes/crear', data),
  actualizar: (data) => api.post('/clientes/actualizar', data),
  eliminar: (clienteId, usuarioId) => api.delete(`/clientes/eliminar/${clienteId}`, { params: { usuarioId } }),
};

export const interesesService = {
  listar: () => api.get('/intereses/listado'),
};

export default api;